package basededatos;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class conexion {
    // Configuración de la conexión a MySQL
    private final String DRIVER = "com.mysql.cj.jdbc.Driver"; // Driver actualizado para MySQL
    private final String URL = "jdbc:mysql://localhost:3307/"; // Puerto 3307 especificado
    private final String DB = "makeaholic"; // Nombre de la base de datos
    private final String USER = "root"; // Usuario de la base de datos
    private final String PASSWORD = ""; // Contraseña vacía (según configuración local)

    public Connection cadena;
    public static conexion instancia;

    private conexion() {
        this.cadena = null;
    }

    public Connection conectar() {
        try {
            Class.forName(DRIVER);
            this.cadena = DriverManager.getConnection(URL + DB, USER, PASSWORD);
        } catch (ClassNotFoundException | SQLException e) {
            JOptionPane.showMessageDialog(null, "Error de conexión: " + e.getMessage());
            System.exit(0);
        }
        return this.cadena;
    }

    public void desconectar() {
        try {
            if (this.cadena != null) {
                this.cadena.close();
            }
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(null, "Error al cerrar conexión: " + e.getMessage());
        }
    }

    public synchronized static conexion getInstancia() {
        if (instancia == null) {
            instancia = new conexion();
        }
        return instancia;
    }
}
